package com.example.electrometer;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;


import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Hooks
        drawerLayout = findViewById(R.id.drawer_Layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        //Toolbar
        setSupportActionBar(toolbar);

        //Navigation drawer menu
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.data:
                Intent intent = new Intent(MainActivity.this,Data.class);
                startActivity(intent);
                break;
            case R.id.nav_Calculate_your_bill:
                Intent intent1 = new Intent(MainActivity.this,CalculateYourBill.class);
                startActivity(intent1);
                break;
            case R.id.Pay_your_bill:
                Intent intent2 = new Intent(MainActivity.this,PayBill.class);
                startActivity(intent2);
                break;
            case R.id.Activate_connection:
                Intent intent3 = new Intent(MainActivity.this,Connection.class);
                startActivity(intent3);
                break;
            case R.id.Recent_Transaction:
                Intent intent4 = new Intent(MainActivity.this,RecentTransactions.class);
                startActivity(intent4);
                break;
            case R.id.nav_profile:
                Intent intent5 = new Intent(MainActivity.this,Profile.class);
                startActivity(intent5);
                break;
            case R.id.nav_help:
                Intent intent6 = new Intent(MainActivity.this,Help.class);
                startActivity(intent6);
                break;
            case R.id.nav_login:
                Intent intent7 = new Intent(MainActivity.this,Login.class);
                startActivity(intent7);
                break;
            case R.id.nav_logout:
                Intent intent8 = new Intent(MainActivity.this,Logout.class);
                startActivity(intent8);
                break;
            case R.id.nav_chat:
                Intent intent9 = new Intent(MainActivity.this,chat.class);
                startActivity(intent9);
                break;
            case R.id.nav_info:
                Intent intent10 = new Intent(MainActivity.this,info.class);
                startActivity(intent10);
                break;

        }
        return true;
    }
}

