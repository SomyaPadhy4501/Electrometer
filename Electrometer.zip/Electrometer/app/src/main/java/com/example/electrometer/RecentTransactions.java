package com.example.electrometer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RecentTransactions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent_transactions);
    }
}